package com.adorno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Anotaciones00ApplicationTests {

	@Test
	void contextLoads() {
	}

}
