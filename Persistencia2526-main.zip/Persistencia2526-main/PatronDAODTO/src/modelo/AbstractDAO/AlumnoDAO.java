package modelo.AbstractDAO;

import modelo.Entity.Alumno;

public interface AlumnoDAO extends GenericDAO<Alumno, String> {

}
